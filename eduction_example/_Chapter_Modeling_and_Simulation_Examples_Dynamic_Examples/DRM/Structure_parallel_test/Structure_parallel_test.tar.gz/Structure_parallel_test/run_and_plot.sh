
rm *.feioutput 

essi -f main.fei



