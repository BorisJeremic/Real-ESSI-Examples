python plot_stress_strain_loop.py
cp full-loop.pdf /home/yuan/Dropbox/Research/multisurface/Document/Figure-files/ch-nonlinear-material-modeling/multiSurface/full-loop.pdf